SHOW DATABASES;

CREATE USER 'yyc'@'%' IDENTIFIED BY 'yyc';

SHOW DATABASES;



USE mysql;

SHOW TABLES;

SELECT * FROM USER;

CREATE DATABASE bunnyroom;


GRANT ALL PRIVILEGES ON bunnyroom.* TO 'yyc'@'%';

SHOW GRANTS FOR 'yyc'@'%';

USE bunnyroom;

SHOW TABLES;